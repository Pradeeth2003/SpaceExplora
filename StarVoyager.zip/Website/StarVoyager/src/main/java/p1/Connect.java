package p1;
import java.sql.*;

public class Connect {
	
	public static Connection con;
	public static Statement st;
	
	public static void connect1() throws Exception{
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/space1","root","tiger");
		st= con.createStatement();
		int i=Integer.pa
	}
}
